import streamlit as st
import streamlit.components.v1 as components
from langchain_community.llms import Ollama
from langchain import LLMChain, PromptTemplate
from neo4j import GraphDatabase
import os
from pyvis.network import Network
import networkx as nx

# Database connection parameters
URI = "bolt://localhost:7687"
USERNAME = "neo4j"
PASSWORD = "root1234"

# Establishing Neo4j connection
def create_neo4j_session(uri, username, password):
    driver = GraphDatabase.driver(uri, auth=(username, password))
    return driver.session()

# Close Neo4j session
def close_neo4j_session(session):
    session.close()

def create_indexes(session):
    session.run("CREATE INDEX IF NOT EXISTS FOR (d:Disease) ON (d.name)")
    session.run("CREATE INDEX IF NOT EXISTS FOR (m:Medication) ON (m.name)")
    session.run("CREATE INDEX IF NOT EXISTS FOR (s:Symptom) ON (s.name)")
    session.run("CREATE INDEX IF NOT EXISTS FOR (c:Composition) ON (c.name)")

session = create_neo4j_session(URI, USERNAME, PASSWORD)
create_indexes(session)
close_neo4j_session(session)

# Define the PromptTemplates for different query types
templates = {
    "disease_to_drugs": """
    Convert the following natural language query into a Cypher query:
    "Fetch all drugs that treat {name}"

    Cypher Query:
    MATCH (:Disease {{name: "{name}"}})-[:TREATS]->(m:Medication) RETURN m.name
    """,
    "drug_to_diseases": """
    Convert the following natural language query into a Cypher query:
    "Fetch all diseases treated by {name}"

    Cypher Query:
    MATCH (:Medication {{name: "{name}"}})-[:TREATS]->(d:Disease) RETURN d.name
    """,
    "symptom_to_diseases": """
    Convert the following natural language query into a Cypher query:
    "Fetch all diseases that have the symptom {name}"

    Cypher Query:
    MATCH (:Symptom {{name: "{name}"}})<-[:HAS_SYMPTOM]-(d:Disease) RETURN d.name
    """,
    "composition_to_drugs": """
    Convert the following natural language query into a Cypher query:
    "Fetch all medications containing the composition {name}"

    Cypher Query:
    MATCH (:Composition {{name: "{name}"}})<-[:CONTAINS]-(m:Medication) RETURN m.name
    """
}

# Initialize the LLM and prompt templates
ollama = Ollama(base_url="http://localhost:11434", model="mistral")

# Function to get the appropriate prompt template
def get_prompt_template(query_type):
    template = templates.get(query_type)
    return PromptTemplate(template=template, input_variables=["name"])

# Function to convert natural language query to Cypher query
def generate_cypher_query(query_type, name):
    prompt = get_prompt_template(query_type)
    llm_chain = LLMChain(prompt=prompt, llm=ollama)
    return llm_chain.run(name=name)

# Function to execute Cypher query
def execute_cypher_query(session, cypher_query):
    result = session.run(cypher_query)
    return [record for record in result]

# Function to extract and format the generated Cypher query
def extract_cypher_query(llm_output):
    start_idx = llm_output.find("MATCH")
    end_idx = llm_output.find("RETURN") + len("RETURN d.name")
    return llm_output[start_idx:end_idx]

def visualize_graph(results, query_type, name):
    G = nx.DiGraph()

    if query_type == "disease_to_drugs":
        disease_node = name
        for record in results:
            drug_node = record["m.name"]
            G.add_node(disease_node, title=disease_node, group=1)
            G.add_node(drug_node, title=drug_node, group=2)
            G.add_edge(disease_node, drug_node)
    elif query_type == "drug_to_diseases":
        drug_node = name
        for record in results:
            disease_node = record["d.name"]
            G.add_node(drug_node, title=drug_node, group=1)
            G.add_node(disease_node, title=disease_node, group=2)
            G.add_edge(drug_node, disease_node)

    net = Network(notebook=False, width="100%", height="500px", directed=True)
    net.from_nx(G)

    path = "graph.html"
    net.save_graph(path)
    return path

# Function to add a new disease
def add_disease(session, disease_name):
    query = "CREATE (d:Disease {name: $name})"
    session.run(query, name=disease_name)

def add_symptom(session, symptom_name):
    query = "CREATE (s:Symptom {name: $name})"
    session.run(query, name=symptom_name)

def add_disease_symptom_relationship(session, disease_name, symptom_name):
    query = """
    MATCH (d:Disease {name: $disease_name})
    MATCH (s:Symptom {name: $symptom_name})
    CREATE (d)-[:HAS_SYMPTOM]->(s)
    """
    session.run(query, disease_name=disease_name, symptom_name=symptom_name)

# Function to add a new medication
def add_medication(session, medication_name):
    query = "CREATE (m:Medication {name: $name})"
    session.run(query, name=medication_name)

def add_composition(session, composition_name):
    query = "CREATE (c:Composition {name: $name})"
    session.run(query, name=composition_name)

def add_medication_composition_relationship(session, medication_name, composition_name):
    query = """
    MATCH (m:Medication {name: $medication_name})
    MATCH (c:Composition {name: $composition_name})
    CREATE (m)-[:CONTAINS]->(c)
    """
    session.run(query, medication_name=medication_name, composition_name=composition_name)

# Function to add a relationship between medication and disease
def add_relationship(session, medication_name, disease_name):
    query = """
    MATCH (m:Medication {name: $med_name})
    MATCH (d:Disease {name: $dis_name})
    CREATE (m)-[:TREATS]->(d)
    """
    session.run(query, med_name=medication_name, dis_name=disease_name)

def fetch_disease_names(session):
    query = "MATCH (d:Disease) RETURN DISTINCT d.name AS name"
    result = session.run(query)
    return [record["name"] for record in result]

def fetch_medication_names(session):
    query = "MATCH (m:Medication) RETURN DISTINCT m.name AS name"
    result = session.run(query)
    return [record["name"] for record in result]

def save_feedback(session, medicine_name, feedback, rating):
    query = """
    MATCH (m:Medication {name: $name})
    SET m.feedback = $feedback, m.rating = $rating
    """
    session.run(query, name=medicine_name, feedback=feedback, rating=rating)

def fetch_feedback_data(session):
    query = """
    MATCH (m:Medication)
    WHERE m.rating IS NOT NULL AND m.feedback IS NOT NULL
    RETURN m.name AS name, m.rating AS rating, m.feedback AS feedback
    """
    result = session.run(query)
    feedback_data = []
    for record in result:
        feedback_data.append({
            "name": record["name"],
            "rating": record["rating"],
            "feedback": record["feedback"]
        })
    return feedback_data

# Streamlit UI
def main():
    st.sidebar.title("Health Buddy - Drug-Disease Discovery")
    selection = st.sidebar.radio("Go to", ["Query System", "Add New Data", "Provide Feedback", "View Feedback Data"])

    if selection == "Query System":
        st.title("Query System")
        try:
            session = create_neo4j_session(URI, USERNAME, PASSWORD)
            disease_names = fetch_disease_names(session)
            medication_names = fetch_medication_names(session)
            close_neo4j_session(session)
        except Exception as e:
            st.error(f"Failed to fetch data from Neo4j: {e}")
            disease_names = []
            medication_names = []

        query_type_label = st.selectbox(
            "Select the type of query:",
            ["Find Medicational Cure for Disease", "Find Diseases Treated by Medicine", "Find Diseases by Symptom", "Find Medications by Composition"]
        )

        if query_type_label == "Find Medicational Cure for Disease":
            query_type = "disease_to_drugs"
            options = disease_names
            name_label = "disease"
        elif query_type_label == "Find Diseases Treated by Medicine":
            query_type = "drug_to_diseases"
            options = medication_names
            name_label = "medicine"
        elif query_type_label == "Find Diseases by Symptom":
            query_type = "symptom_to_diseases"
            options = []
            name_label = "symptom"
        elif query_type_label == "Find Medications by Composition":
            query_type = "composition_to_drugs"
            options = []
            name_label = "composition"

        name = st.selectbox(f"Enter the {name_label} name:", options) if options else st.text_input(f"Enter the {name_label} name:")

        if st.button("Submit"):
          with st.spinner("Executing Query...") :
            try:
                cypher_query = generate_cypher_query(query_type, name)
                extracted_query = extract_cypher_query(cypher_query)

                st.write(extracted_query)

                session = create_neo4j_session(URI, USERNAME, PASSWORD)
                result = execute_cypher_query(session, extracted_query)
                close_neo4j_session(session)

                st.subheader("Results")
                if result:
                    st.write("Results : ")
                    results = [record["m.name"] for record in result]
                    if results:
                        # Display results as a table
                        st.table({"Results": results})

                        graph_html_path = visualize_graph(result, query_type, name)
                        if os.path.exists(graph_html_path):
                            with open(graph_html_path, "r") as file:
                                graph_html = file.read()
                            # st.components.html(graph_html, height=600)
                            components.html(graph_html, height=600)
                    else:
                        st.write("No results found.")
                
                close_neo4j_session(session)
            except Exception as e:
                st.write("Query execution failed:", e)



    elif selection == "Add New Data":
        st.title("Add New Data")
        st.write("Fill in the details to add new data to the database.")
        
        session = create_neo4j_session(URI, USERNAME, PASSWORD)
        disease_names = fetch_disease_names(session)
        medication_names = fetch_medication_names(session)
        close_neo4j_session(session)

        new_disease_name = st.text_input("New Disease Name")
        if st.button("Add Disease"):
            try:
                session = create_neo4j_session(URI, USERNAME, PASSWORD)
                add_disease(session, new_disease_name)
                close_neo4j_session(session)
                st.success(f"Disease '{new_disease_name}' added successfully.")
            except Exception as e:
                st.error(f"Failed to add disease: {e}")

        new_symptom_name = st.text_input("New Symptom Name")
        if st.button("Add Symptom"):
            try:
                session = create_neo4j_session(URI, USERNAME, PASSWORD)
                add_symptom(session, new_symptom_name)
                close_neo4j_session(session)
                st.success(f"Symptom '{new_symptom_name}' added successfully.")
            except Exception as e:
                st.error(f"Failed to add symptom: {e}")

        if disease_names and new_symptom_name:
            selected_disease_name = st.selectbox("Select Disease for Symptom", disease_names)
            if st.button("Add Disease-Symptom Relationship"):
                try:
                    session = create_neo4j_session(URI, USERNAME, PASSWORD)
                    add_disease_symptom_relationship(session, selected_disease_name, new_symptom_name)
                    close_neo4j_session(session)
                    st.success(f"Relationship between disease '{selected_disease_name}' and symptom '{new_symptom_name}' added successfully.")
                except Exception as e:
                    st.error(f"Failed to add relationship: {e}")

        new_medication_name = st.text_input("New Medication Name")
        if st.button("Add Medication"):
            try:
                session = create_neo4j_session(URI, USERNAME, PASSWORD)
                add_medication(session, new_medication_name)
                close_neo4j_session(session)
                st.success(f"Medication '{new_medication_name}' added successfully.")
            except Exception as e:
                st.error(f"Failed to add medication: {e}")

        new_composition_name = st.text_input("New Composition Name")
        if st.button("Add Composition"):
            try:
                session = create_neo4j_session(URI, USERNAME, PASSWORD)
                add_composition(session, new_composition_name)
                close_neo4j_session(session)
                st.success(f"Composition '{new_composition_name}' added successfully.")
            except Exception as e:
                st.error(f"Failed to add composition: {e}")

        if medication_names and new_composition_name:
            selected_medication_name = st.selectbox("Select Medication for Composition", medication_names)
            if st.button("Add Medication-Composition Relationship"):
                try:
                    session = create_neo4j_session(URI, USERNAME, PASSWORD)
                    add_medication_composition_relationship(session, selected_medication_name, new_composition_name)
                    close_neo4j_session(session)
                    st.success(f"Relationship between medication '{selected_medication_name}' and composition '{new_composition_name}' added successfully.")
                except Exception as e:
                    st.error(f"Failed to add relationship: {e}")

        if disease_names and medication_names:
            selected_medication_name_for_disease = st.selectbox("Select Medication for Disease", medication_names)
            selected_disease_name_for_medication = st.selectbox("Select Disease for Medication", disease_names)
            if st.button("Add Medication-Disease Relationship"):
                try:
                    session = create_neo4j_session(URI, USERNAME, PASSWORD)
                    add_relationship(session, selected_medication_name_for_disease, selected_disease_name_for_medication)
                    close_neo4j_session(session)
                    st.success(f"Relationship between medication '{selected_medication_name_for_disease}' and disease '{selected_disease_name_for_medication}' added successfully.")
                except Exception as e:
                    st.error(f"Failed to add relationship: {e}")

    elif selection == "Provide Feedback":
        st.title("Provide Feedback")
        try:
            session = create_neo4j_session(URI, USERNAME, PASSWORD)
            medication_names = fetch_medication_names(session)
            close_neo4j_session(session)
        except Exception as e:
            st.error(f"Failed to fetch data from Neo4j: {e}")
            medication_names = []

        selected_medication_feedback = st.selectbox("Select Medication for Feedback", medication_names)
        feedback = st.text_area("Feedback")
        rating = st.slider("Rating", 1, 5)
        if st.button("Submit Feedback"):
            try:
                session = create_neo4j_session(URI, USERNAME, PASSWORD)
                save_feedback(session, selected_medication_feedback, feedback, rating)
                close_neo4j_session(session)
                st.success(f"Feedback for medication '{selected_medication_feedback}' submitted successfully.")
            except Exception as e:
                st.error(f"Failed to submit feedback: {e}")

    elif selection == "View Feedback Data":
        st.title("Feedback Data")
        try:
            session = create_neo4j_session(URI, USERNAME, PASSWORD)
            feedback_data = fetch_feedback_data(session)
            close_neo4j_session(session)
            if feedback_data:
                st.table(feedback_data)
            else:
                st.write("No feedback data available.")
        except Exception as e:
            st.error(f"Failed to fetch feedback data: {e}")

if __name__ == "__main__":
    main()
